=== Driggle Nachrichten ===
Contributors: DrgFlips
Tags: driggle, nachrichten, news
Requires at least: 2.8
Tested up to: 2.8
Stable tag: 1.0

Driggle Nachrichten liefert Ihnen die neusten
Schlagzeilen direkt in den Blog.

== Description ==

Driggle Nachrichten erlaubt es Ihnen auf Ihrem 
Blog die neusten Schlagzeilen anzeigen zu lassen. 
Sie k�nnen selber einstellen, aus welchem 
Themenbereich die Schlagzeilen erstellt werden,
wie sie geordnet werden und wie viele angezeigt
werden. 

== Installation ==

Laden Sie die Datei driggle_news_de.php in das 
Plugin-Verzeichnis, dieses befindet sich f�r   
gew�hnlich im Ordner wp-plugins.

Haben Sie diesen Schritt beendet, melden Sie 
sich bitte im Admin Panel an und rufen die
Seite Plugins auf.

Dort m�ssten Sie einen Eintrag mit dem Titel
"Driggle Nachrichten" sehen. Darunter befindet
sich ein Link, �ber den Sie das Plugin
aktivieren k�nnen. Dieser Link tr�gt in der
deutschen Wordpress Version den Namen
"Aktivieren" und in der Englischen "Activate".

Ist das Plugin Aktiviert, rufen Sie bitte die
Seite Widgets auf. Dort m�sste nun ein neues
Widget verf�gbar sein "Driggle Nachrichten".
Dieses ziehen Sie in eine verf�gbare Sidebar.

Nun ist das Widget aktiv und zeigt die neusten
Schlagzeilen auf Ihrem Blog an.

Das Widget l�sst sich bequem �ber das Admin
Panel konfigurieren.

�ffnen Sie dazu die Seite Widgets im Admin
Panel und Klappen Sie den Eintrag
"Driggle Nachrichten" in der Sidebar aus.

Es erscheint nun ein Formular mit dem Sie
die Einstellungen bearbeiten k�nnen.

== Screenshots ==

1. Driggle Nachrichten eingebunden in das Standard Theme
2. Driggle Nachrichten eingebunden in ein anderes Theme
3. Driggle Nachrichten Konfiguration